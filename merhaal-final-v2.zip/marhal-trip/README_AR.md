# مرحال - دليل التشغيل الكامل

## نظرة عامة

مرحال هو موقع ويب متكامل لتخطيط الرحلات السياحية داخل المملكة العربية السعودية. يتضمن نظام تسجيل دخول داخلي، قاعدة بيانات كاملة للوجهات والأنشطة، وخوارزمية ذكية لتوليد جداول الرحلات.

## المتطلبات الأساسية

قبل البدء، تأكد من تثبيت:

1. **Node.js** (الإصدار 22 أو أحدث)
   - تحميل من: https://nodejs.org/
   - تحقق من التثبيت: `node --version`

2. **pnpm** (مدير الحزم)
   - تثبيت: `npm install -g pnpm`
   - تحقق من التثبيت: `pnpm --version`

3. **PostgreSQL** (الإصدار 14 أو أحدث)
   - تحميل من: https://www.postgresql.org/download/
   - تحقق من التشغيل: `psql --version`

## خطوات التشغيل السريع

### 1. فك ضغط الملفات

```bash
unzip marhal-trip.zip
cd marhal-trip
```

### 2. تثبيت الحزم

```bash
pnpm install
```

### 3. إعداد قاعدة البيانات

#### أ. إنشاء قاعدة بيانات PostgreSQL

```bash
# تسجيل الدخول إلى PostgreSQL
psql -U postgres

# إنشاء قاعدة بيانات جديدة
CREATE DATABASE marhal_trip;

# الخروج
\q
```

#### ب. إعداد ملف المتغيرات البيئية

أنشئ ملف `.env` في المجلد الرئيسي:

```env
# رابط قاعدة البيانات
DATABASE_URL=postgresql://postgres:password@localhost:5432/marhal_trip

# مفتاح التشفير (استخدم مفتاح عشوائي قوي)
JWT_SECRET=your-very-secret-random-key-here-change-this

# إعدادات التطبيق
VITE_APP_TITLE=مرحال - مخطط الرحلات السياحية
VITE_APP_LOGO=/logo.png

# إعدادات الخادم
PORT=3000
NODE_ENV=development
```

**مهم جداً:** غيّر `JWT_SECRET` إلى مفتاح عشوائي قوي!

#### ج. تطبيق هيكل قاعدة البيانات

```bash
pnpm db:push
```

#### د. إدخال البيانات الأولية

```bash
node seed-data.mjs
```

هذا الأمر سيُدخل:
- 4 وجهات سياحية (الرياض، جدة، العلا، أبها)
- 15 نشاط سياحي
- 12 فندق
- 10 مطعم

### 4. تشغيل الموقع

#### للتطوير (مع إعادة التحميل التلقائي):

```bash
pnpm dev
```

افتح المتصفح على: `http://localhost:3000`

#### للإنتاج:

```bash
# بناء المشروع
pnpm build

# تشغيل الخادم
pnpm start
```

## هيكل المشروع

```
marhal-trip/
├── client/                    # تطبيق React الأمامي
│   ├── public/                # الملفات الثابتة (صور، أيقونات)
│   └── src/
│       ├── components/        # المكونات القابلة لإعادة الاستخدام
│       ├── contexts/          # سياقات React (Theme, Auth)
│       ├── hooks/             # خطافات مخصصة
│       ├── lib/               # مكتبات مساعدة
│       └── pages/             # صفحات الموقع
│           ├── Home.tsx       # الصفحة الرئيسية
│           ├── Login.tsx      # تسجيل الدخول
│           ├── Register.tsx   # إنشاء حساب
│           ├── Dashboard.tsx  # لوحة التحكم
│           ├── PlanTrip.tsx   # تخطيط الرحلة
│           ├── Guides.tsx     # المرشدون
│           ├── About.tsx      # من نحن
│           ├── Support.tsx    # الدعم
│           └── Packages.tsx   # الباقات
│
├── server/                    # خادم Node.js الخلفي
│   ├── _core/                 # وظائف الخادم الأساسية
│   ├── db.ts                  # دوال قاعدة البيانات
│   └── routers.ts             # مسارات API (tRPC)
│
├── drizzle/                   # هيكل قاعدة البيانات
│   └── schema.ts              # تعريف الجداول
│
├── shared/                    # أنواع وثوابت مشتركة
│   └── const.ts
│
├── seed-data.mjs              # سكريبت إدخال البيانات
├── .env.example               # مثال لملف المتغيرات
├── package.json               # إعدادات المشروع
└── README_AR.md               # هذا الملف
```

## المميزات الرئيسية

### 1. نظام المصادقة الداخلي
- تسجيل دخول بالبريد الإلكتروني وكلمة المرور
- تشفير كلمات المرور باستخدام bcrypt
- إدارة الجلسات بـ JWT tokens

### 2. تخطيط الرحلات الذكي
- خوارزمية ذكية لتوليد جداول مخصصة
- اختيار الوجهة والميزانية والاهتمامات
- 3 باقات: مجاني، ذكي، احترافي

### 3. قاعدة بيانات شاملة
- 4 وجهات سياحية رئيسية
- أنشطة متنوعة (ثقافية، ترفيهية، طبيعية)
- فنادق بفئات مختلفة
- مطاعم متنوعة

### 4. واجهة متعددة اللغات
- العربية (الافتراضية)
- الإنجليزية
- تبديل سلس بين اللغات

### 5. الوضع الليلي/النهاري
- تصميم متجاوب مع الثيمات
- ألوان سعودية (أخضر وذهبي)

## الباقات المتاحة

### مجاني (Free)
- معاينة النظام
- رحلة واحدة (يوم واحد)
- 3 أنشطة كحد أقصى
- لا يمكن حفظ الخطط

### ذكي (Smart) - 14.99 ريال (دفعة واحدة)
- رحلات حتى 10 أيام
- 5 أنشطة في اليوم
- حفظ 3 خطط
- خوارزمية التخطيط الذكي
- فلاتر متقدمة

### احترافي (Professional) - 29.99 ريال/شهرياً
- رحلات حتى 14 يوماً
- أنشطة غير محدودة
- حفظ غير محدود
- حجز مباشر للفنادق
- حجز مرشدين سياحيين
- دعم أولوية 24/7

## قاعدة البيانات

### الجداول الرئيسية:

1. **users** - المستخدمون
   - البريد الإلكتروني، كلمة المرور المشفرة، الاسم، الهاتف، المدينة، الباقة

2. **destinations** - الوجهات
   - الاسم، الوصف، الصورة، المنطقة

3. **activities** - الأنشطة
   - الوجهة، الاسم، النوع، المدة، السعر، الباقة المطلوبة

4. **hotels** - الفنادق
   - الوجهة، الاسم، النجوم، السعر لليلة

5. **restaurants** - المطاعم
   - الوجهة، الاسم، نوع المطبخ، متوسط السعر

6. **trips** - الرحلات المحفوظة
   - المستخدم، الوجهة، عدد الأيام، الميزانية، الاهتمامات، الجدول (JSON)

7. **favorites** - المفضلة
   - المستخدم، الوجهة

## النشر على خادم حقيقي

### الخيار 1: Vercel (مجاني)

1. أنشئ حساب على https://vercel.com
2. اربط مستودع GitHub
3. أضف متغيرات البيئة في لوحة التحكم
4. انشر تلقائياً

### الخيار 2: Railway (سهل)

1. أنشئ حساب على https://railway.app
2. أنشئ مشروع جديد
3. أضف قاعدة بيانات PostgreSQL
4. اربط مستودع GitHub
5. انشر

### الخيار 3: VPS (خادم خاص)

#### على Ubuntu/Debian:

```bash
# تحديث النظام
sudo apt update && sudo apt upgrade -y

# تثبيت Node.js
curl -fsSL https://deb.nodesource.com/setup_22.x | sudo -E bash -
sudo apt install -y nodejs

# تثبيت pnpm
npm install -g pnpm

# تثبيت PostgreSQL
sudo apt install -y postgresql postgresql-contrib

# إعداد قاعدة البيانات
sudo -u postgres psql
CREATE DATABASE marhal_trip;
CREATE USER marhal_user WITH PASSWORD 'strong_password';
GRANT ALL PRIVILEGES ON DATABASE marhal_trip TO marhal_user;
\q

# رفع الملفات
# (استخدم scp أو git clone)

# تثبيت PM2 لإدارة العملية
npm install -g pm2

# تشغيل المشروع
cd marhal-trip
pnpm install
pnpm db:push
node seed-data.mjs
pnpm build
pm2 start "pnpm start" --name marhal-trip
pm2 save
pm2 startup
```

### إعداد Nginx (اختياري للمجال المخصص)

```nginx
server {
    listen 80;
    server_name yourdomain.com;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
```

## حل المشاكل الشائعة

### 1. خطأ في الاتصال بقاعدة البيانات

```
Error: connect ECONNREFUSED 127.0.0.1:5432
```

**الحل:**
- تأكد من تشغيل PostgreSQL: `sudo systemctl status postgresql`
- تحقق من `DATABASE_URL` في ملف `.env`
- تأكد من صحة اسم المستخدم وكلمة المرور

### 2. المنفذ مستخدم بالفعل

```
Error: listen EADDRINUSE: address already in use :::3000
```

**الحل:**
```bash
# إيقاف العملية المستخدمة للمنفذ
lsof -ti:3000 | xargs kill

# أو غيّر المنفذ في ملف .env
PORT=3001
```

### 3. أخطاء في بناء المشروع

**الحل:**
```bash
# حذف الملفات المؤقتة
rm -rf node_modules dist .vite

# إعادة التثبيت
pnpm install

# إعادة البناء
pnpm build
```

### 4. البيانات لا تظهر

**الحل:**
```bash
# إعادة إدخال البيانات
node seed-data.mjs
```

### 5. خطأ JWT_SECRET

```
Error: JWT_SECRET is not defined
```

**الحل:**
- تأكد من وجود ملف `.env` في المجلد الرئيسي
- أضف `JWT_SECRET=your-secret-key` في الملف

## الأوامر المفيدة

```bash
# تشغيل التطوير
pnpm dev

# بناء المشروع
pnpm build

# تشغيل الإنتاج
pnpm start

# تحديث قاعدة البيانات
pnpm db:push

# إعادة إدخال البيانات
node seed-data.mjs

# اختبار المشروع
pnpm test

# فحص الأخطاء
pnpm lint
```

## الدعم والمساعدة

إذا واجهت أي مشاكل:

1. تحقق من ملف `DEPLOYMENT.md` للتفاصيل الإنجليزية
2. راجع قسم "حل المشاكل الشائعة" أعلاه
3. تأكد من تثبيت جميع المتطلبات بشكل صحيح
4. تحقق من سجلات الأخطاء في Terminal

## الترخيص

هذا المشروع مفتوح المصدر ومتاح للاستخدام الشخصي والتجاري.

---

**تم التطوير بواسطة Manus AI** 🤖
